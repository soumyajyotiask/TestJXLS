package net.sf.jxls.reader.sample;

import java.util.Date;

/**
 * @author Leonid Vysochyn
 * @version 1.0 28.07.2007
 */
public class SimpleBean {
    Integer intValue1;
    Double doubleValue;
    String str;
    Integer intValue2;
    Integer intValue3;
    Integer intValue4;
    Date dateValue;


    public Integer getIntValue4() {
        return intValue4;
    }

    public void setIntValue4(Integer intValue4) {
        this.intValue4 = intValue4;
    }

    public Integer getIntValue2() {
        return intValue2;
    }

    public void setIntValue2(Integer intValue2) {
        this.intValue2 = intValue2;
    }

    public Integer getIntValue3() {
        return intValue3;
    }

    public void setIntValue3(Integer intValue3) {
        this.intValue3 = intValue3;
    }

    public Integer getIntValue1() {
        return intValue1;
    }

    public void setIntValue1(Integer intValue1) {
        this.intValue1 = intValue1;
    }

    public Double getDoubleValue() {
        return doubleValue;
    }

    public void setDoubleValue(Double doubleValue) {
        this.doubleValue = doubleValue;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public Date getDateValue() {
        return dateValue;
    }

    public void setDateValue(Date dateValue) {
        this.dateValue = dateValue;
    }
}
