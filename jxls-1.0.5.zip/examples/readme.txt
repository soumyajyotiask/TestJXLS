README
======

This folder contains examples demonstrating all main features of jXLS library (http://jxls.sourceforge.net).
Folder examples/src/main/java contains the examples source code and  examples/src/main/resources/templates contains Excel template files.
To compile and run examples in the easiest way you may want to install Maven 2 (http://maven.apache.org) go to examples folder and type
mvn compile site
After build is succesful the result Excel files can be found in the examples/target directory.
