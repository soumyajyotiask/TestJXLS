package net.sf.jxls.sample.dynamicColumns;


public class FundsVO {
	private String eenheden;
	private String waarde;
	private String verkoopkosten;
	
	public String getEenheden() {
	
		return eenheden;
	}
	
	public void setEenheden(String eenheden) {
	
		this.eenheden = eenheden;
	}
	
	public String getVerkoopkosten() {
	
		return verkoopkosten;
	}
	
	public void setVerkoopkosten(String verkoopkosten) {
	
		this.verkoopkosten = verkoopkosten;
	}
	
	public String getWaarde() {
	
		return waarde;
	}
	
	public void setWaarde(String waarde) {
	
		this.waarde = waarde;
	}
	
}
